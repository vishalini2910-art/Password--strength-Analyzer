let lastPassword = "";

function togglePassword() {
    const input = document.getElementById("password");
    const button = event.target;

    if (input.type === "password") {
        input.type = "text";
        button.textContent = "Hide";
    } else {
        input.type = "password";
        button.textContent = "Show";
    }
}

async function analyzePassword() {
    const password = document.getElementById("password").value;

    try {
        const response = await fetch("/analyze", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({password})
        });

        const data = await response.json();

        if (!response.ok) {
            alert(data.error);
            return;
        }

        lastPassword = password;

        document.getElementById("result").classList.remove("hidden");
        document.getElementById("strength").textContent = data.strength;
        document.getElementById("length").textContent =
            data.length + " characters";

        document.getElementById("unique").textContent =
            data.unique ? "Not previously used" : "Already used";

        document.getElementById("scoreFill").style.width =
            Math.min((data.score / 6) * 100, 100) + "%";

        const list = document.getElementById("suggestions");
        list.innerHTML = "";

        if (data.suggestions.length === 0) {
            const li = document.createElement("li");
            li.textContent = "Excellent! No improvements are required.";
            list.appendChild(li);
        } else {
            data.suggestions.forEach(item => {
                const li = document.createElement("li");
                li.textContent = item;
                list.appendChild(li);
            });
        }
    } catch (error) {
        alert("Cannot connect to the Flask backend. Start app.py first.");
    }
}

async function generatePassword() {
    try {
        const response = await fetch("/generate");
        const data = await response.json();

        document.getElementById("generated").classList.remove("hidden");
        document.getElementById("generatedPassword").textContent = data.password;
    } catch (error) {
        alert("Cannot connect to the Flask backend. Start app.py first.");
    }
}

function useGenerated() {
    const password =
        document.getElementById("generatedPassword").textContent;

    document.getElementById("password").value = password;
    analyzePassword();
}

async function savePassword() {
    if (!lastPassword) {
        alert("Analyze a password first.");
        return;
    }

    const response = await fetch("/save", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({password: lastPassword})
    });

    const data = await response.json();
    alert(data.message || data.error);
}
