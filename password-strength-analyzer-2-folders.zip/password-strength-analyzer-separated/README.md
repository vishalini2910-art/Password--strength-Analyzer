# Password Strength Analyzer

This project is separated into two folders:

- `backend/` - Python Flask API and password analysis logic
- `frontend/` - HTML, CSS and JavaScript UI

## Run

Keep both folders inside the same project directory.

Open a terminal in `backend`:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open:

```text
http://127.0.0.1:5000
```

The Flask backend serves the frontend and handles the `/analyze`, `/generate`, and `/save` endpoints.

## Folder Structure

```text
password-strength-analyzer/
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   ├── README.md
│   └── .gitignore
│
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
│
└── README.md
```
