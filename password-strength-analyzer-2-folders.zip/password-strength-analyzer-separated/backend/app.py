import secrets
import string
import hashlib
from pathlib import Path
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)
USED_PASSWORDS_FILE = Path("used_passwords.txt")


def password_hash(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def is_unique(password):
    if not USED_PASSWORDS_FILE.exists():
        return True
    saved = USED_PASSWORDS_FILE.read_text(encoding="utf-8").splitlines()
    return password_hash(password) not in saved


def save_password_hash(password):
    with USED_PASSWORDS_FILE.open("a", encoding="utf-8") as file:
        file.write(password_hash(password) + "\n")


def check_password(password):
    score = 0
    suggestions = []

    if len(password) >= 8:
        score += 1
    else:
        suggestions.append("Use at least 8 characters.")

    if len(password) >= 12:
        score += 1

    if any(c.islower() for c in password):
        score += 1
    else:
        suggestions.append("Add lowercase letters.")

    if any(c.isupper() for c in password):
        score += 1
    else:
        suggestions.append("Add uppercase letters.")

    if any(c.isdigit() for c in password):
        score += 1
    else:
        suggestions.append("Add numbers.")

    if any(c in string.punctuation for c in password):
        score += 1
    else:
        suggestions.append("Add special characters such as !, @, # or $.")

    unique = is_unique(password)

    if not unique:
        suggestions.append("This password was already used. Choose a new one.")

    if score <= 2:
        strength = "Weak"
    elif score <= 4:
        strength = "Medium"
    elif score == 5:
        strength = "Strong"
    else:
        strength = "Very Strong"

    return {
        "strength": strength,
        "score": score,
        "length": len(password),
        "unique": unique,
        "suggestions": suggestions
    }


def generate_password(length=16):
    alphabet = string.ascii_letters + string.digits + string.punctuation

    while True:
        password = "".join(secrets.choice(alphabet) for _ in range(length))

        if (
            any(c.islower() for c in password)
            and any(c.isupper() for c in password)
            and any(c.isdigit() for c in password)
            and any(c in string.punctuation for c in password)
        ):
            return password


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    password = data.get("password", "")

    if not password:
        return jsonify({"error": "Please enter a password."}), 400

    return jsonify(check_password(password))


@app.route("/generate")
def generate():
    return jsonify({"password": generate_password()})


@app.route("/save", methods=["POST"])
def save():
    data = request.get_json()
    password = data.get("password", "")

    if not password:
        return jsonify({"error": "Password cannot be empty."}), 400

    if not is_unique(password):
        return jsonify({"error": "This password has already been used."}), 409

    save_password_hash(password)
    return jsonify({"message": "Password hash saved successfully."})


if __name__ == "__main__":
    app.run(debug=True)
