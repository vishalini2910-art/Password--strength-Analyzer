# Password Strength Analyzer - Backend

This folder contains the Python Flask backend.

## Run

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

## Features

- Password length checking
- Lowercase/uppercase checking
- Number checking
- Special-character checking
- Password reuse checking
- Secure password generation using Python `secrets`
- SHA-256 hash storage for the educational reuse-check feature

## Important

This is an educational cybersecurity project. Production authentication systems should use password-specific hashing algorithms such as Argon2id, scrypt, or bcrypt rather than plain SHA-256.
